
#######Libraries for xgboost (and more)######

libraries_xgboost <- function() {
  #call hierarhicla the module files with inclusive functions, which are passed with: $
  # install.packages("modules")
  library(modules)
  # embed a Python session in R
  # install.packages("reticulate")
  library(reticulate)
  # For weekly updated version of CRAN
  # install.packages("drat", repos="https://cran.rstudio.com")
  # drat:::addRepo("dmlc")
  # --for SMOTE --
  # install.packages("DMwR")
  # --for subset of a dataframe--
  library(dplyr)
  # # --for regexpr in r--
  # # install.packages("stringr")
  # library(stringr)
  # --for dates--
  # install.packages("tidyr")
  library(tidyr)
  #--for SMOTE--
  require(DMwR)
  library(DMwR)
  #--sparse matrix--
  library(Matrix)
  #--Xgboost--
  # install.packages("xgboost")
  library(drat)
  library(xgboost)
  require(xgboost)
  # for roc curve as evaluation metric
  # install.packages('pROC')
  library(pROC)
}