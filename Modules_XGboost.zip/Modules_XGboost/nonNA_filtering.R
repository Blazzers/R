# non NA percentage
nonNA_filtering <- function (dataset, threshold) {
  perc <- colSums(!is.na(dataset)) * 100 / (nrow(dataset))
  cat(sprintf('The features of dataset {%s} with percentage of NA > {%d} removed successfuly', deparse(substitute(dataset)),threshold))
  # non NA percentage should be greater than 10% to keep the feature
  return(dataset[perc > threshold])
}
