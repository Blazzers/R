rm(list = ls())
# proxy_auth <- new("proxy_authentication",
#                   http_proxy = "",)
print("Enable and run the comment to update the R version")
# source('R_version_update.R')
# R_version_update()

print("--Libraries for xgboost (and more)--")
source('libraries_xgboost.R')
libraries_xgboost()

csv_path = 'C:\\Users\\xnmparout\\Desktop\\data_sets\\'
source('loadDatasets.R')
loadDataset(csv_path)

print('--Convert blank sells to NA--')
source('convert_toNA.R')
train = blankCell_to_NA(train)
test = blankCell_to_NA(test)

setwd('C:\\Users\\xnmparout\\Desktop\\OTE\\NikosR\\Modules')
# import('DateProc_module.R') #use() is only from inside the module for its submodules

source('DateProc_module.R')
train_sep_dates<- DateProcessing(train)
test_sep_dates <- DateProcessing(test)
#10 fold CV split
print('-- Set perc_oversample hyperparameter inside SMOTE for different dimensions dataset--')
source('SMOTE_balancing.R')
balanced_train <- SMOTE_balancing(train)
balanced_test <- SMOTE_balancing(test)

print('--Check the type of DF and convert to numeric for matrix conversion and algorithmic compatibility--')
source('checkType_and_convert.R')
balanced_train <- checkType_and_convert(balanced_train)
balanced_train <- checkType_and_convert(balanced_train)

print('--xXgboost--')
source('algorithm_xgboost.R')
algorithm_xgboost(balanced_train)
