convert_toNA <- function (dataset) {
  print(('NULL, null and blank cells convert to NA'))
  dataset <- replace(dataset, dataset == 'NULL' |
              dataset == 'null' | dataset == '', NA)
  return(dataset)
}
