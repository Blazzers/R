# Transaction transformation from a matrix class 
# accepted to Eclat for tid-id list
# insertion to Neural Network architectures.

dataset <-  read.table(
  "C:/Users/xnmparout/Desktop/OTE/NikosR/fullLLU.csv",
  header = TRUE,
  sep = ",",
  encoding = "UTF-8"
)

source('C:\\Users\\xnmparout\\Desktop\\OTE\\NikosR\\Eclat\\eclat_fun.R')
eclat_itemsets <- eclat_fun(dataset, 0.8)

source('C:\\Users\\xnmparout\\Desktop\\OTE\\NikosR\\Eclat\\Conv_one_zero_itemsets.R')
Conv_one_zero_itemsets(eclat_itemsets)

