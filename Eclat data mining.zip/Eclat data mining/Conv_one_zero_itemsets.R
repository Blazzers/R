Conv_one_zero_itemsets <- function(eclat_itemsets)
{
  indx1 <- floor(1 * nrow(eclat_itemsets@items@data) / 5)
  indx1
  itm <- eclat_itemsets@items@data[1:indx1, ]
  
  library(Matrix)
  showClass('lMatrix')
  Matrix(itm) -> "lMatrix"
  memory.limit(size = 8090)
  l <- as(itm, "lsparseMatrix")
  object.size(l)
  dim(l)
  z <- as.logical(l)
  df_binary <- as.data.frame(replace(z, z == TRUE , 1))
  df_binary <- as.data.frame(replace(z, z == FALSE, 0))
  df_binary
  
  print(paste0('--reduced memory to--', format(object.size(z), 'Mb')))
  print(paste0(
    '--memory of dataframe itemsets binary--',
    format(object.size(df_binary), 'Mb')
  ))
  
  memory.limit(size = 8090)
  gc()
  gcinfo(TRUE)
  dim(Eclat_itemsetsBinary)
  
  print(paste0('--eclat itemsets memory--', format(
    object.size(Eclat_itemsetsBinary), 'Mb'
  )))
  
  #write to csv for neural network insertion
  print('write one zero dataframe to csv, it takes a while')
  write.table(
    Eclat_itemsetsBinary,
    "C:\\Users\\xnmparout\\Desktop\\data_sets\\eclat_items_dataset.csv"
  )
  return(eclat_itemsets@items@data)
}
