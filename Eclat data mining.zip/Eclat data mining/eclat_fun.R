
# Time Compliexity of tow Rule mining Algorithms:
# Eclat=O(P*P)+O(P) < FP-Growth= O(F)+O(T*C)<< Apriori= O(F*D*C)
# P= itemsets #F= frequent_itemsets, T= num_transactions,
# C= new_candidate_sets
# D= database

#retuns the itemsets in sparse matrix
eclat_fun <- function(dataset, support_val) {

# Data mining algorithms accepts non-integers types.
check_ConvFactor <- function (dataset)
{
  for (i in 1:ncol(dataset)) {
    if (is.factor(dataset[, i]) == FALSE) {
      dataset[, i] <- as.factor(dataset[, i])
    }
  }
  return(dataset)
}

  library(dplyr)
  # convert to NA
  print(('--NULL, null and blank tuples converted to NA--'))
  dataset <- replace(dataset, dataset == 'NULL' |
                       dataset == 'null' | dataset == '', NA)
  
  dataset <- check_ConvFactor(dataset)
  
  library(arules)
  library(methods)
  
  #arules works with tid id lists also named as transactional
  dfTotransaction <- as(dataset, 'transactions')
  dim(dfTotransaction)
  print(paste0('--converted type--', class(dfTotransaction)))
  
  eclat_itemsets <-
    eclat(dfTotransaction, parameter = list(support = support_val, tidList = TRUE))
  
  # in case of memory fullness 
  print(paste0('--eclat itemsets memory--', format(object.size(eclat_itemsets), 'Mb')))
  print(paste0(
    '--eclat from itemsets@items@data produces a sparse matrix--',
    format(object.size(eclat_itemsets@items@data), 'Mb')
  ))
  cat('--dimensions of itemsets in Tid-id list format--',dim(eclat_itemsets@items@data))
  return('eclat_itemsets@items@data')
}

