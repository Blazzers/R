
################## FAMD: Factor Analysis of Mixed Data################

famdAnalysis <- function(dataset){
  # install.packages("ggplot2")
  #install.packages("plyr")
  library("plyr")
  #install.packages("FactoMineR")
  library("FactoMineR")
  #install.packages("factoextra")
  library("factoextra")
  
  # version #chk version for compatibility of packages because R maybe is obsolete

  res.famd<-FAMD(dataset, ncp = 5, graph=TRUE)
  
  fviz_screeplot(res.famd)
  # Quantitative variables
  fviz_famd_var(res.famd, "quanti.var",repel=TRUE, col.var = "black")
  fviz_famd_var(res.famd, "quali.var", repel=TRUE,col.var = "black")
  fviz_famd_ind(res.famd,addEllipses = TRUE, col.quali.var = "black")
  fviz_famd_ind(res.famd, geom = c("point"), col.ind = "cos2",
                gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
                repel = TRUE, addEllipses = TRUE)
  fviz_famd_var(res.famd, geom = c("point"), col.ind = "cos2",
                gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
                repel = TRUE, addEllipses = TRUE)
  
  
  summary(res.famd)
  plot(res.famd,invisible=c("var","quali.sup","quanti.sup"),cex=0.7)
  plot(res.famd,invisible=c("ind","quali.sup","quanti.sup"),cex=0.8)
  plot(res.famd,invisible=c("quali.sup","quanti.sup"),cex=0.8)
  dimdesc(res.famd)
}
