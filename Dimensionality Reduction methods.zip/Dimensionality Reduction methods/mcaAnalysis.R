

##################### MCA analysis ####################

mcaAnalysis <- function(dataset, col_num){
  
  res.mca <- MCA(dataset, graph=FALSE)
  summary(res.mca)
  plot(res.mca,invisible=c("var","quali.sup","quanti.sup"),cex=0.7)
  plot(res.mca,invisible=c("ind","quali.sup","quanti.sup"),cex=0.8)
  plot(res.mca,invisible=c("quali.sup","quanti.sup"),cex=0.8)
  
  #Factor Map
  fviz_mca_biplot(res.mca, 
                  repel = TRUE, # Avoid text overlapping (slow if many point)
                  ggtheme = theme_minimal())
  
  dimdesc(res.mca)
  plotellipses(res.mca)
  graph.var(res.mca)
  eig.val <- res.mca$eig
  # plot one column
  barplot(eig.val[, col_num], 
          names.arg = 2:nrow(eig.val), 
          main = "Variances Explained by Dimensions (%)",
          xlab = "Principal Dimensions",
          ylab = "Percentage of variances",
          col ="steelblue")
  # Add connected line segments to the plot
  lines(x = 1:nrow(eig.val), eig.val[, cln],  #
        type = "b", pch = 19, col = "red")
}